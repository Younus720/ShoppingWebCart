package com.younus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingWebCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
