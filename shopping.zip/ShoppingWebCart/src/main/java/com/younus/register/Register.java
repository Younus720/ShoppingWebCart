package com.younus.register;

import org.springframework.data.repository.CrudRepository;

import com.younus.bean.LoginBean;

public interface Register extends CrudRepository<LoginBean, String> {

}