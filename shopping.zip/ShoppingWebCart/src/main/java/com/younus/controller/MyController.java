package com.younus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.younus.mojo.Product;
import com.younus.bean.LoginBean;
import com.younus.dao.LoginDAO;
import com.younus.productDao.productDao;



@Controller
public class MyController {
	@Autowired
	LoginDAO dao;
	productDao dao2;
	
	@RequestMapping("Start")
	  public ModelAndView CallStart()
	  {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("LandingPage");
		  return mv;
	  }
	@RequestMapping("RegistrationPage")
	  public ModelAndView CallRegistrationPage()
	  {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("Registration");
		  return mv;
	  }
	
	@RequestMapping("LoginPage")
	  public ModelAndView CallLoginPage()
	  {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("Login");
		  return mv;
	  }
	@RequestMapping("Register")
	  public ModelAndView register(LoginBean login)
	  {
		  ModelAndView mv = new ModelAndView();
		  dao.save(login);
		  mv.setViewName("LandingPage");
		  mv.addObject("msg","Register Successfuly");
		  return mv;
	  }
	
	@RequestMapping("Login")
  public ModelAndView Login(LoginBean login)
  {
	  ModelAndView mv = new ModelAndView();
	  LoginBean tmp = dao.findById(login.getUsername()).get();
	  if(tmp.getPassword().equals(login.getPassword())){
		  mv.setViewName("LoginSuccess");
	  }
	  else {
		  mv.setViewName("Login");
		  mv.addObject("msg","LoginFailed");
	  }
		return mv;
	}
	
	@RequestMapping("Product")
	  public ModelAndView CallProduct()
	  {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("Product");
		  return mv;
	  }
	  
	  @RequestMapping("ProductName")
	  public ModelAndView CallProductName()
	  {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("ProductName");
		  return mv;
	  }
	  
	  @RequestMapping("InsertProduct")
	  public ModelAndView CallInsertProduct()
	  {
		  ModelAndView mv = new ModelAndView();
		  mv.setViewName("InsertProduct");
		  return mv;
	  }

	  @RequestMapping("SaveProduct")
	  public ModelAndView saveProductAndView (Product product)
	  {
		  ModelAndView mv = new ModelAndView();
		  dao2.save(product);
		  mv.setViewName("SaveProduct");
		  return mv;
	  
	
}
}
