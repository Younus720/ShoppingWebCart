package com.younus.productDao;
import org.springframework.data.repository.CrudRepository;

import com.younus.mojo.Product;

public interface productDao extends CrudRepository<Product ,Integer> {

}