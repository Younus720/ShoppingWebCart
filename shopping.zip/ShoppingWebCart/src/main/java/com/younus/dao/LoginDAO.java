package com.younus.dao;

import org.springframework.data.repository.CrudRepository;

import com.younus.bean.LoginBean;

public interface LoginDAO extends CrudRepository<LoginBean, String> {

}
