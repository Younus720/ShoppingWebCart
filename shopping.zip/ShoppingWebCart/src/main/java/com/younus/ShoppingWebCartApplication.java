package com.younus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingWebCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingWebCartApplication.class, args);
	}

}
